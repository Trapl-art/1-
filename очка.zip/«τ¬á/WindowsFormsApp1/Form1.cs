﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {

        private string[] textData;


        public Form1()
        {
            InitializeComponent();
            textData = new string[10];

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            textData[0] = "№ заявки:" + textBox1.Text;
            textData[1] = "Оборудование которое было замененно: " + textBox2.Text;
            textData[2] = "Оборудование, которое требует ремонта; " + textBox3.Text;
            textData[3] = "Тип неисправности: " + textBox4.Text;
            textData[4] = "Описание проблемы: " + textBox5.Text;
            textData[5] = "Клиент, который подал заявку " + textBox6.Text;
            textData[6] = " Статус: " + textBox7.Text;
            textData[7] = "начало взятия в работу: " + textBox8.Text;
            textData[8] = "окончание взятие в работу: " + textBox9.Text;
            textData[9] = "Дата добавление " + dateTimePicker1.Text;

            foreach (var item in textData)
            {
                listBox1.Items.Add(item); 

            }
            listBox1.Items.Add("-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            
        }
    }
}
