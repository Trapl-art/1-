﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form2 : Form
    {
        private List<List<string>> dataGridList; // Объявление списка списков

        public Form2()
        {
            InitializeComponent();
            dataGridList = new List<List<string>>(); // Инициализация списка

            InitializeDataGridView(); // Инициализация столбцов DataGridView
        }

        private void InitializeDataGridView()
        {
            dataGridView1.ColumnCount = 4; // Установка количества столбцов
            dataGridView1.Columns[0].Name = "Название";
            dataGridView1.Columns[1].Name = "Количество";
            dataGridView1.Columns[2].Name = "Цена";
            dataGridView1.Columns[3].Name = "Номер детали";
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Проверка на пустые поля
            if (string.IsNullOrEmpty(textBox1.Text) || string.IsNullOrEmpty(textBox2.Text) || string.IsNullOrEmpty(textBox3.Text) || string.IsNullOrEmpty(textBox4.Text))
            {
                MessageBox.Show("Пожалуйста, заполните все поля.");
                return;
            }

            try
            {
                // Создаем список для новых данных
                List<string> newData = new List<string>
                {
                    textBox1.Text,
                    textBox2.Text,
                    textBox3.Text,
                    textBox4.Text
                };

                // Добавляем новые данные в список
                dataGridList.Add(newData);

                // Обновляем DataGridView
                dataGridView1.Rows.Add(newData.ToArray()); // Передаем массив для добавления в DataGridView

                // Очистка текстовых полей
                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                textBox4.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message);
            }
        }

        private void DisplayArrayInDataGridView()
        {
            dataGridView1.Rows.Clear(); // Очищаем DataGridView перед заполнением
            foreach (var row in dataGridList)
            {
                dataGridView1.Rows.Add(row.ToArray());
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Здесь можно добавить функционал для кнопки 2, если требуется
        }
    }
}